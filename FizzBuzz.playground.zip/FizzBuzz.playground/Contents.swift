//: Playground - noun: a place where people can play

import UIKit

for i in 1...105
{
    if i % 3 == 0 {
        if i % 5 == 0 {
            if i % 7 == 0 {
                print ("Fizz-Buzz-Bang")
            }
            else {
                print ("Fizz-Buzz")
            }
        }
        else {
            print ("Fizz")
        }
    }
    else if i % 5 == 0 {
        print ("Buzz")
    }
    else if i % 7 == 0 {
        print ("Bang")
    }
    else {
        print (i)
    }
}
